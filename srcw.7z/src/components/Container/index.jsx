import React from "react";
import { DesktopContainer } from "./style";

// eslint-disable-next-line
export default ({ children }) => {
  return <DesktopContainer>{children}</DesktopContainer>;
};
