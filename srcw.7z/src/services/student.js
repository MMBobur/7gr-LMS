import { service } from ".";

export default {
  getStudents: () => service.get("/students"),
  delStudent: (id) => service.delete(`/students/${id}`),
  putStudent: (id, data) => service.put(`/students/${id}`, data),
};
