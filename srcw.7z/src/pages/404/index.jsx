import React from "react";

export default () => {
  return <div>Sahifa topilmadi</div>;
};
