export default function toUpper(str) {
  let a = str[0].toUpperCase() + str.slice(1);

  return a;
}
